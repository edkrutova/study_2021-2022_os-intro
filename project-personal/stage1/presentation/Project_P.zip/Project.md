---
## Front matter
lang: ru-RU
title: Индивидуальный проект
author: |
	Ekaterina D. Krutova\inst{1}
institute: |
	\inst{1}RUDN University, Moscow, Russian Federation
date: NEC--2022, 31 Feb -- 31 Feb, 2022 Moscow, Russia

## Formatting
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true
---
# Цель работы

Выполнить первый этап индивидуального проекта, разместив на Github pages заготовки для персонального сайта.

# Задание

- Установить необходимое программное обеспечение.

- Скачать шаблон темы сайта.

- Разместить его на хостинге git.

- Установить параметр для URLs сайта.

- Разместить заготовку сайта на Github pages

# Ход работы

Я следовала инструкциям из инструкции ([ссылка на видео](https://www.youtube.com/watch?v=OpsSv0RE3C4)).

Итоговый результат выполнения представлен на рис. [-@fig:001]

![созданный сайт](proj/Screenshot_02.png){ #fig:001 width=70% }

# Вывод

Выполнен первый этап индивидуального проекта.

Спасибо за внимание
