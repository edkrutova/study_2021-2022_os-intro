---
## Front matter
title: "Индивидуальный проект"
subtitle: "Первый этап"
author: "Крутова Екатерина Дмитриевна"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
lot: true # List of tables
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Рис."
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы:

Выполнить первый этап индивидуального проекта, разместив на Github pages заготовки для персонального сайта.

# Задание

- Установить необходимое программное обеспечение.

- Скачать шаблон темы сайта.

- Разместить его на хостинге git.

- Установить параметр для URLs сайта.

- Разместить заготовку сайта на Github pages

# Выполнение лабораторной работы

1. **Выполнение**

Я следовала инструкциям из инструкции ([ссылка на видео](https://www.youtube.com/watch?v=OpsSv0RE3C4)).

Основные команды представлены на рис. [-@fig:001]-[-@fig:011]

Примечание: некоторые команды смены директори (cd <каталог>) были опущены.

![перенос файла hugo из загрузок в папку bin](proj/Screenshot_1.png){ #fig:001 width=70% }

![клонирование репозитория blog, созданного на github](proj/Screenshot_2.png){ #fig:002 width=70% }

![вызов hugo](proj/Screenshot_3.png){ #fig:003 width=70% }

![вызов hugo server и запуск сервера](proj/Screenshot_4.png){ #fig:004 width=70% }

![клонирование репозитория](proj/Screenshot_5.png){ #fig:005 width=70% }

![создание новой ветви ветви, файла README, выгрузка на github](proj/Screenshot_6.png){ #fig:006 width=70% }

![неудачная попытка из-за игнорирования](proj/Screenshot_7.png){ #fig:007 width=70% }

![измененный файл](proj/Screenshot_8.png){ #fig:008 width=70% }

![успех и hugo](proj/Screenshot_12.png){ #fig:009 width=70% }

![проверка успеха](proj/Screenshot_9.png){ #fig:010 width=70% }

![ещё изменения](proj/Screenshot_10.png){ #fig:011 width=70% }

![итоговая выгрузка на github](proj/Screenshot_11.png){ #fig:012 width=70% }

2. **Промежуточные и итоговые результаты**

Итоговые и промежуточные результаты представлены на рис. [-@fig:013]-[-@fig:015]

![версия hugo, которая была установлена](proj/Screenshot_0.png){ #fig:013 width=70% }

![репозиторий сайта](proj/Screenshot_01.png){ #fig:014 width=70% }

![созданный сайт](proj/Screenshot_02.png){ #fig:015 width=70% }

# Выводы

Выполнен первый этап индивидуального проекта.
