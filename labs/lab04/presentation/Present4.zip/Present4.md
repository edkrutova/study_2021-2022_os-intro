---
## Front matter
lang: ru-RU
title: Laboratornaya rabota 4
author: |
	Ekaterina D. Krutova\inst{1}
institute: |
	\inst{1}RUDN University, Moscow, Russian Federation
date: NEC--2022, 31 Feb -- 31 Feb, 2022 Moscow, Russia

## Formatting
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true
---
# Цель работы

Приобретение практических навыков взаимодействия пользователя с системой посредством командной строк.

# Теоретическое введение

В операционной системе типа Linux взаимодействие пользователя с системой обычно осуществляется с помощью командной строки посредством построчного ввода команд. При этом обычно используется командные интерпретаторы языка shell: /bin/sh; /bin/csh; /bin/ksh.

Общий формат команд можно представить следующим образом:
<имя_команды><разделитель><аргументы>

# Ход работы

С помощью консоли и ввода различных команд я создавала/удаляла подкаталоги, выводила на экран необходимую информацию в соответсвии с заданием.

Например, Вывод с помощью команды ls -l содержимого домашнего каталога и определение его владельца(рис. [-@fig:001])

![edkrutova - владелец файлов и подкаталогов](pics4/Screenshot_9.png){ #fig:007 width=70% }

# Вывод

Я приобрела практические навыки взаимодействия пользователя с системой посредством командной строки.

# Список литературы
