---
## Front matter
lang: ru-RU
title: Laboratornaya rabota 3
author: |
	Ekaterina D. Krutova\inst{1}
institute: |
	\inst{1}RUDN University, Moscow, Russian Federation
date: NEC--2022, 31 Feb -- 31 Feb, 2022 Moscow, Russia

## Formatting
toc: false
slide_level: 2
theme: metropolis 
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true
---
# Цель работы

Научиться оформлять отчёты с помощью легковесного языка разметки Markdown

# Теоретическое введение

Markdown (произносится маркда́ун) — облегчённый язык разметки, созданный с целью обозначения форматирования в простом тексте, с максимальным сохранением его читаемости человеком, и пригодный для машинного преобразования в языки для продвинутых публикаций (HTML, Rich Text и других). [Информация взята из wikipedia.](https://ru.wikipedia.org/wiki/Markdown)

# Ход работы

Используя шаблон, скачанный с [https://github.com](https://github.com/yamadharma/academic-laboratory-report-template) (и преобразованный под пользователя (Рисунок [-@fig:001])), я форматировала текст отчёта, сделанного в Word.

![шаблон](pics3/Screenshot_28.png){ #fig:001 width=70% }

Были отформатированы:

- Заголовки

- Списки

- Скриншоты

# Вывод

Я научилась оформлять отчёты с помощью легковесного языка разметки Markdown

Спасибо за внимание!

# Список литературы

[Wikipedia.](https://ru.wikipedia.org/wiki/Markdown)
